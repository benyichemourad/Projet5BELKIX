@extends('template')

@section('title')
    Le nom de mon jeu
@endsection

@section('contenu')
    Mon contenu
@endsection