<div>
    <!-- Smile, breathe, and go slowly. - Thich Nhat Hanh -->
    Mon composant d'alerte
</div>