<div>
    <!-- Order your soul. Reduce your wants. - Augustine -->
    <button>Un bouton</button>
</div>