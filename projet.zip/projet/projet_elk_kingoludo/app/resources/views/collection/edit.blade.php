@extends('welcome')

@section('content')
    Edition d'une collection
@endsection