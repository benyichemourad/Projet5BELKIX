<?php

return [
    'liste_jeux' => 'Games List',
];