<?php

return [
    'liste_users' => 'Liste des utilisateurs',
];