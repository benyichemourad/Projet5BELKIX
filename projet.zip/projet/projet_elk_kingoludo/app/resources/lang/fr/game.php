<?php

return [
    'liste_jeux' => 'Liste des jeux',
];