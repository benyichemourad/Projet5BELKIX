<div>
    <!-- Smile, breathe, and go slowly. - Thich Nhat Hanh -->
    Mon composant d'alerte
</div><?php /**PATH /var/www/html/resources/views/components/alert-component.blade.php ENDPATH**/ ?>