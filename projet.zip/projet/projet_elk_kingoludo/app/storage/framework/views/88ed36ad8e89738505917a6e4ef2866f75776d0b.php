<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('titre'); ?></title>
    <link href="/css/app.css" rel="stylesheet" type="text/css"></head>
<body>
    <?php if (isset($component)) { $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlertComponent::class, []); ?>
<?php $component->withName('alert-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8)): ?>
<?php $component = $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8; ?>
<?php unset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8); ?>
<?php endif; ?>
    Mon super template
    
    <?php echo $__env->yieldContent('contenu'); ?>
</body>
</html><?php /**PATH /var/www/html/resources/views/template.blade.php ENDPATH**/ ?>